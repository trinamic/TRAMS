//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2016-06-09 11:52:04

#include "Arduino.h"
#include "Configuration.h"
#include "pins.h"
#include <LiquidCrystal_I2C.h>
#include <LiquidTWI2.h>
#include <U8glib.h>
#include <LiquidCrystal.h>
#include <SPI.h>
#include <Wire.h>
#include <Wire.h>
#include <Wire.h>

#include "TRAMS-Marlin.ino"

#include "Marlin.pde"
